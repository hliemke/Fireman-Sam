iArduino
========

 iArduino is an app which allows you to control your Arduino Board over a WiFi Network with the help of Arduino Ethernet Shield and your iOS devices like iPhone, iPod Touch and iPad. You can control output of each pin individually. With the help of iArduino app and your Ideas you can create variety of projects and control them Wirelessly with faster response of the iArduino App.
 
 If you have not downloaded tha app already then you can get it from the App Store.
 
 iArduino Full Version:
 https://itunes.apple.com/us/app/iarduino-full-version/id647120575?ls=1&mt=8
 
 iArduino Lite Version:
 https://itunes.apple.com/us/app/iarduino/id578582005?ls=1&mt=8
 
 
 iArduino App Currently supports following boards:
 
1. Official Arduino Ethernet Shield
 http://arduino.cc/en/Main/ArduinoEthernetShield
(Download Ethernet Shield + WIFI Router version of iArduino Code)

2. Arduino Ethernet Board
 http://arduino.cc/en/Main/ArduinoBoardEthernet
(Download Ethernet Shield + WIFI Router version of iArduino Code)
 
3. RN-XV Wifly Module
https://www.sparkfun.com/products/10822
(Download RN-XV Wifly Module version of iArduino Code)


4. SeeedStudio Ethernet Shield
http://www.seeedstudio.com/depot/ethernet-shield-p-518.html
(Download Ethernet Shield + WIFI Router version of iArduino Code)

5. Freetronic Ethernet Shield
http://www.freetronics.com/collections/shields/products/ethernet-shield-with-poe#.Ur16u3mTq5c
(Download Ethernet Shield + WIFI Router version of iArduino Code)

6. EtherTen Shield from Freetronics
http://www.freetronics.com/products/etherten#.Ur17iHmTq5d
(Download Ethernet Shield + WIFI Router version of iArduino Code)

7. And most of the Ethrenet shields with Wiznet W5100 chip on board.


